import discord
import os
import requests
import json 

client = discord.Client()

joke_start = [
  "Hey Joke Bot",
  "hey Joke Bot",
  "hey Joke bot",
  "hey joke Bot",
  "hey joke bot",
  "@Joke Bot"
]

def get_joke():
  response = requests.get("https://v2.jokeapi.dev/joke/Any?blacklistFlags=nsfw,religious,political,racist,sexist,explicit&type=single")
  api_data = json.loads(response.text)
  joke = '%s' %(api_data['joke'])
  return (joke)

@client.event
async def on_ready():
  print('We have logged in as {0.user}'.format(client))

@client.event
async def on_message(message):
  if message.author == client.user:
    return

  if message.content.startswith('$joke'):
    await message.channel.send(get_joke())
    
  if message.content.startswith('haha'):
    await message.channel.send('Not funny. Do not laugh again. *Or else* :knife:')
    
  if any(word in message.content for word in joke_start):
    await message.channel.send('Hey! Wanna hear a joke? Just use ***$joke!*** :joy:')
 
  if message.content.startswith('hm'):
    await message.channel.send('hm')

client.run(os.getenv('TOKEN'))